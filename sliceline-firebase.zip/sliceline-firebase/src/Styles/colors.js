export const pizzaRed = "#f44336";
