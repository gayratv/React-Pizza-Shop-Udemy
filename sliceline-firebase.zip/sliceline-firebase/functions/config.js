module.exports = {
  email: 'YOUR EMAIL',
  password: 'YOUR PASSWORD'
}
